package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    private TextView resultText;
    private EditText TextTextPersonName2, TextTextPersonName3;
    private Button add_but, add_butte, add_butten, add_buttener;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultText = findViewById(R.id.resultText);
        TextTextPersonName2 = findViewById(R.id.editTextTextPersonName2);
        TextTextPersonName3 = findViewById(R.id.editTextTextPersonName3);
        add_but = findViewById(R.id.add_but);
        add_butte = findViewById(R.id.add_butte);
        add_butten = findViewById(R.id.add_butten);
        add_buttener = findViewById(R.id.add_buttener);

        add_but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float num1 = Float.parseFloat(TextTextPersonName2.getText().toString());
                float num2 = Float.parseFloat(TextTextPersonName3.getText().toString());
                float res = num1 + num2;
                resultText.setText(String.valueOf(res));




            }
        });

        add_butte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vy) {
                float num3 = Float.parseFloat(TextTextPersonName2.getText().toString());
                float num4 = Float.parseFloat(TextTextPersonName3.getText().toString());
                float res = num3 - num4;
                resultText.setText(String.valueOf(res));




            }
        });

        add_butten.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vr) {
                float num5 = Float.parseFloat(TextTextPersonName2.getText().toString());
                float num6 = Float.parseFloat(TextTextPersonName3.getText().toString());
                float res = num5 * num6;
                resultText.setText(String.valueOf(res));




            }
        });

        add_buttener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View ve) {
                float num7 = Float.parseFloat(TextTextPersonName2.getText().toString());
                float num8 = Float.parseFloat(TextTextPersonName3.getText().toString());
                float res = num7 / num8;
                resultText.setText(String.valueOf(res));




            }
        });


    }
}
